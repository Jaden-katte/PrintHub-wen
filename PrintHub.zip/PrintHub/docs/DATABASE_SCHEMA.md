# PrintHub Database Schema

**DBMS:** SQLite (file: `backend/printhub.db`)  
**Design principles:** Relational, clear naming, primary keys, foreign keys, appropriate data types.

## Entity Relationship Overview

```
users 1──* orders 1──* order_items *──1 services
  │           │
  │           └──* payments
  │           └──* files
  └──* quotations *──1 services
```

## Tables

### users
| Column         | Type    | Constraints              | Description                |
|----------------|---------|--------------------------|----------------------------|
| id             | INTEGER | PRIMARY KEY AUTOINCREMENT| Unique user ID             |
| name           | TEXT    | NOT NULL                 | Full name                  |
| email          | TEXT    | NOT NULL UNIQUE          | Login email                |
| password_hash  | TEXT    |                          | bcrypt hash (empty for SSO)|
| phone          | TEXT    |                          | Optional phone             |
| role           | TEXT    | NOT NULL DEFAULT 'customer'| customer / admin         |
| sso_provider   | TEXT    |                          | e.g. google                |
| sso_id         | TEXT    |                          | External provider ID       |
| created_at     | TEXT    | DEFAULT datetime('now')  | Creation timestamp         |

### services
| Column      | Type    | Constraints              | Description              |
|-------------|---------|--------------------------|--------------------------|
| id          | INTEGER | PRIMARY KEY AUTOINCREMENT|                          |
| name        | TEXT    | NOT NULL                 | Service name             |
| description | TEXT    |                          |                          |
| category    | TEXT    | NOT NULL                 | Print, Large Format, etc.|
| base_price  | REAL    | NOT NULL                 | Unit price in ZAR        |
| unit        | TEXT    | DEFAULT 'item'           | Pricing unit             |
| active      | INTEGER | DEFAULT 1                | Soft delete flag         |
| created_at  | TEXT    |                          |                          |

### quotations
| Column          | Type    | Constraints     | Description          |
|-----------------|---------|-----------------|----------------------|
| id              | INTEGER | PK              |                      |
| user_id         | INTEGER | FK → users      |                      |
| service_id      | INTEGER | FK → services   |                      |
| quantity        | INTEGER | DEFAULT 1       |                      |
| options         | TEXT    | JSON            | Extra options        |
| notes           | TEXT    |                 |                      |
| estimated_price | REAL    |                 | Calculated estimate  |
| status          | TEXT    | DEFAULT pending | pending / approved   |
| created_at      | TEXT    |                 |                      |

### orders
| Column       | Type    | Constraints     | Description                          |
|--------------|---------|-----------------|--------------------------------------|
| id           | INTEGER | PK              |                                      |
| user_id      | INTEGER | FK → users      |                                      |
| status       | TEXT    | DEFAULT pending | pending, confirmed, in_production…   |
| total_amount | REAL    | NOT NULL        |                                      |
| notes        | TEXT    |                 |                                      |
| created_at   | TEXT    |                 |                                      |
| updated_at   | TEXT    |                 |                                      |

### order_items
| Column     | Type    | Constraints   | Description     |
|------------|---------|---------------|-----------------|
| id         | INTEGER | PK            |                 |
| order_id   | INTEGER | FK → orders   |                 |
| service_id | INTEGER | FK → services |                 |
| quantity   | INTEGER | DEFAULT 1     |                 |
| options    | TEXT    | JSON          |                 |
| unit_price | REAL    | NOT NULL      | Snapshot price  |
| line_total | REAL    | NOT NULL      | qty × unit_price|

### files
| Column        | Type    | Constraints  | Description        |
|---------------|---------|--------------|--------------------|
| id            | INTEGER | PK           |                    |
| order_id      | INTEGER | FK → orders  | Optional link      |
| user_id       | INTEGER | FK → users   | Uploader           |
| original_name | TEXT    | NOT NULL     | Client filename    |
| stored_name   | TEXT    | NOT NULL     | Server filename    |
| mime_type     | TEXT    |              |                    |
| size_bytes    | INTEGER |              |                    |
| uploaded_at   | TEXT    |              |                    |

### payments
| Column         | Type    | Constraints  | Description     |
|----------------|---------|--------------|-----------------|
| id             | INTEGER | PK           |                 |
| order_id       | INTEGER | FK → orders  |                 |
| amount         | REAL    | NOT NULL     |                 |
| method         | TEXT    | DEFAULT card | card / eft      |
| status         | TEXT    | DEFAULT pending |              |
| transaction_id | TEXT    |              | Simulated TXN ID|
| paid_at        | TEXT    |              |                 |

## Seed Data
The `seed.js` script inserts **≥ 10 records** into every major table with realistic South African names, printing services and order history.

## Indexes & Integrity
- Email unique constraint on users.
- Foreign keys defined for referential integrity.
- Status values constrained at application layer.
