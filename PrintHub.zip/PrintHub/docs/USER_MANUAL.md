# PrintHub User Manual

## 1. Introduction
PrintHub is an online printing management system available as a website and Android mobile application. Customers can browse services, request quotations, place orders, upload design files and track progress. Administrators manage services and order statuses.

## 2. Getting Started

### Website
1. Open the website in a modern browser.
2. Ensure the backend API is running (`node server.js` in the `backend` folder).
3. Click **Register** to create an account or **Login** if you already have one.

### Android App
1. Install the APK on an Android device (API 26+).
2. Configure the API base URL in BuildConfig (or use the default for emulator: `http://10.0.2.2:3000/api/`).
3. For a physical device on the same network, change the URL to your computer’s LAN IP.
4. Launch the app and register / log in.

### Default Accounts (after seeding)
| Role     | Email                        | Password      |
|----------|------------------------------|---------------|
| Admin    | admin@printhub.co.za         | Admin@2026    |
| Customer | thabo.molefe@email.com       | Password123!  |

## 3. Customer Features

### Registration & Login
- Register with name, email, optional phone and password (min 6 characters). Passwords are hashed with bcrypt.
- Login with email + password.
- **SSO Demo**: Use “Continue with Google” on the website or app (simulated SSO for demonstration).

### Browse Services
View all available printing and design services with prices and categories.

### Request a Quotation
Select a service, enter quantity and notes. The system calculates an estimated price.

### Place & Track Orders
View order history and current status (pending → confirmed → in production → ready → shipped/completed).

### Account Settings
Update your name, phone number and change your password (current password required).

## 4. Administrator Features
Log in with the admin account. Access the Admin Dashboard to:
- View statistics (customers, orders, revenue).
- See all orders and update their status.

## 5. Security Notes
- Passwords are never stored in plain text (bcrypt, cost factor 12).
- JWT tokens are used for session management.
- Mobile app stores the token in EncryptedSharedPreferences.
- SSO endpoint is provided for integration with Google / other identity providers.

## 6. Troubleshooting
- **Cannot connect to API**: Ensure the backend is running and the API_BASE_URL is correct. Physical devices need the machine’s LAN IP, not localhost.
- **Invalid credentials**: Check email spelling and password. Use the seeded accounts after running `node seed.js`.
- **App crashes on invalid input**: All main forms validate input and show friendly error messages; the app should not crash.

## 7. Support
For academic support contact your lecturer or the PrintHub project team.
