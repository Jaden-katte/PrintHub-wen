# PrintHub Online Printing Management System

**XISD6329 – Work Integrated Learning 3B – Task 2**

**Diploma in IT Software Development**  
The Independent Institute of Education (IIE)

## Team Members

| Name | Student Number | Role |
|------|----------------|------|
| Boineelo Agosi Mkansie | ST10328452 | System Analyst / Developer |
| Nkateko Baloyi | ST10439475 | Project Manager |
| Khaogelo Matlala | ST10453718 | Web Developer |
| Danny Riba | ST10449040 | Web Developer |
| Kgotso Molefe | ST10457638 | Database Developer |
| Ntlakuso Banyini | ST10438428 | UI/UX Designer |

## Project Overview

PrintHub is a full-stack Online Printing Management System consisting of:

- **REST API** (Node.js + Express + SQLite)
- **Website** (HTML/CSS/JavaScript)
- **Android Mobile Application** (Kotlin)

Customers can browse services, request quotations, upload design files, place orders, make payments and track order status. Administrators manage services, orders and view reports.

## Features Implemented (Task 2)

### Authentication & Security
- User registration and login with **bcrypt password hashing** (cost factor 12)
- JWT-based session tokens
- **Single Sign-On (SSO)** support (Google-style SSO endpoint)
- Secure settings page (change name, phone, password)

### Mobile App Requirements
- Runs on physical Android device
- Registration / Login / SSO
- Settings menu
- Browse services
- Request quotations
- Place orders & track status
- File upload
- Order history
- User-friendly UI with input validation (no crashes on invalid input)

### Backend / API
- Full REST API with authentication middleware
- Database: SQLite with proper relational schema
- Tables: users, services, quotations, orders, order_items, files, payments
- Each table seeded with **≥ 10 realistic records**
- File upload support (PDF, images, design files)
- Admin endpoints for order status updates and statistics

### DevOps
- GitHub repository with clear folder structure
- Multiple meaningful commits
- GitHub Actions workflow for Android build & unit tests
- Azure DevOps Kanban board used for task tracking (documented)

### Documentation
- Comprehensive user guide
- Installation & setup instructions
- API documentation
- Database schema documentation

## Project Structure

```
PrintHub/
├── backend/                 # Node.js REST API
│   ├── server.js
│   ├── database.js
│   ├── seed.js
│   ├── package.json
│   └── uploads/
├── website/                 # Frontend website
│   ├── index.html
│   ├── css/
│   ├── js/
│   └── pages/
├── android-app/             # Kotlin Android application
│   ├── app/
│   │   └── src/main/java/com/printhub/
│   ├── build.gradle.kts
│   └── ...
├── docs/                    # Additional documentation
├── .github/workflows/       # GitHub Actions
└── README.md
```

## Quick Start – Backend API

```bash
cd backend
npm install
node seed.js          # Populate database with sample data
node server.js        # Start API on http://localhost:3000
```

**Default accounts after seeding:**
- Admin: `admin@printhub.co.za` / `Admin@2026`
- Customer: `thabo.molefe@email.com` / `Password123!`

## API Endpoints (selected)

| Method | Endpoint | Description | Auth |
|--------|----------|-------------|------|
| POST | /api/auth/register | Register new customer | No |
| POST | /api/auth/login | Login | No |
| POST | /api/auth/sso | SSO login | No |
| GET  | /api/auth/me | Current user profile | Yes |
| PUT  | /api/auth/settings | Update profile/password | Yes |
| GET  | /api/services | List services | No |
| POST | /api/quotations | Create quotation | Yes |
| POST | /api/orders | Place order | Yes |
| GET  | /api/orders | List user/admin orders | Yes |
| PATCH| /api/orders/:id/status | Update status (admin) | Admin |
| POST | /api/orders/:id/files | Upload file | Yes |
| POST | /api/orders/:id/payments | Process payment | Yes |
| GET  | /api/admin/stats | Dashboard stats | Admin |

## Android App

Open the `android-app` folder in Android Studio (Hedgehog or later recommended).

- Minimum SDK: 26 (Android 8.0)
- Target SDK: 34
- Language: Kotlin
- UI: Jetpack Compose + Material 3
- Networking: Retrofit + OkHttp
- Auth storage: EncryptedSharedPreferences
- Image loading: Coil

Build a signed APK or install via USB debugging on a physical device for the demonstration video.

## GitHub Actions

The workflow `.github/workflows/android.yml` builds the Android app and runs unit tests on every push to `main`.

## Demonstration Video

A professional demonstration video with voice-over showing all features (including data in the database/API) will be uploaded to YouTube (unlisted) and linked here:

**Video link:** *[To be added after recording on physical device]*

## Release Notes (v1.0 – Task 2)

- Full working Android application
- Complete REST API with authentication, SSO, file upload
- Relational database with 10+ records per table
- Password encryption (bcrypt)
- Settings management
- Automated testing pipeline
- Updated website with responsive design
- User documentation and help system

## Licence

Academic project for IIE XISD6329 – 2026. All rights reserved by the student team.
