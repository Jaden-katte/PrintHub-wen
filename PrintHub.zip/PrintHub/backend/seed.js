/**
 * Seed the PrintHub database with realistic sample data (10+ records per major table)
 */

const bcrypt = require('bcryptjs');
const db = require('./database');

async function seed() {
  await db.init();

  // Clear existing data (order matters for FKs)
  await db.run('DELETE FROM payments');
  await db.run('DELETE FROM files');
  await db.run('DELETE FROM order_items');
  await db.run('DELETE FROM orders');
  await db.run('DELETE FROM quotations');
  await db.run('DELETE FROM services');
  await db.run('DELETE FROM users');

  const hash = await bcrypt.hash('Password123!', 12);
  const adminHash = await bcrypt.hash('Admin@2026', 12);

  // ---- Users (12) ----
  const users = [
    ['Admin User', 'admin@printhub.co.za', adminHash, '0820000001', 'admin'],
    ['Thabo Molefe', 'thabo.molefe@email.com', hash, '0821111001', 'customer'],
    ['Lerato Dlamini', 'lerato.d@email.com', hash, '0821111002', 'customer'],
    ['Sipho Nkosi', 'sipho.n@email.com', hash, '0821111003', 'customer'],
    ['Nomsa Khumalo', 'nomsa.k@email.com', hash, '0821111004', 'customer'],
    ['Johan van der Berg', 'johan.vdb@email.com', hash, '0821111005', 'customer'],
    ['Fatima Hassan', 'fatima.h@email.com', hash, '0821111006', 'customer'],
    ['Pieter Botha', 'pieter.b@email.com', hash, '0821111007', 'customer'],
    ['Ayanda Zulu', 'ayanda.z@email.com', hash, '0821111008', 'customer'],
    ['Michelle Smith', 'michelle.s@email.com', hash, '0821111009', 'customer'],
    ['Kagiso Modise', 'kagiso.m@email.com', hash, '0821111010', 'customer'],
    ['Priya Patel', 'priya.p@email.com', hash, '0821111011', 'customer']
  ];

  for (const u of users) {
    await db.run(
      `INSERT INTO users (name, email, password_hash, phone, role, created_at) VALUES (?, ?, ?, ?, ?, datetime('now'))`,
      u
    );
  }
  console.log('Seeded 12 users');

  // ---- Services (12) ----
  const services = [
    ['Business Cards (Standard)', 'Premium 350gsm matte or gloss business cards, double sided', 'Print', 150.00, 'pack of 100'],
    ['Business Cards (Premium Foil)', 'Luxury cards with gold/silver foil stamping', 'Print', 350.00, 'pack of 100'],
    ['A4 Flyers (Colour)', 'Full colour A4 flyers on 150gsm gloss', 'Print', 2.50, 'each'],
    ['A5 Flyers (Colour)', 'Full colour A5 flyers on 150gsm gloss', 'Print', 1.80, 'each'],
    ['Posters A1', 'Large format A1 posters, indoor or outdoor', 'Large Format', 180.00, 'each'],
    ['Banners (Vinyl)', 'Vinyl banners with eyelets, custom size', 'Large Format', 450.00, 'sqm'],
    ['Pull-up Banners', 'Retractable pull-up banner stands including print', 'Display', 850.00, 'each'],
    ['Brochures (Tri-fold)', 'A4 tri-fold brochures, full colour both sides', 'Print', 8.50, 'each'],
    ['Letterheads', 'Corporate letterheads on premium bond paper', 'Print', 3.20, 'each'],
    ['Stickers (Die-cut)', 'Custom die-cut vinyl stickers', 'Promotional', 5.00, 'each'],
    ['T-Shirt Printing', 'Screen print or DTG custom t-shirts', 'Apparel', 120.00, 'each'],
    ['Custom Design Package', 'Professional graphic design service for any print product', 'Design', 750.00, 'project']
  ];

  for (const s of services) {
    await db.run(
      `INSERT INTO services (name, description, category, base_price, unit, active, created_at) VALUES (?, ?, ?, ?, ?, 1, datetime('now'))`,
      s
    );
  }
  console.log('Seeded 12 services');

  // ---- Quotations (12) ----
  for (let i = 1; i <= 12; i++) {
    const userId = (i % 11) + 2; // customers 2-12
    const serviceId = (i % 12) + 1;
    const qty = Math.floor(Math.random() * 50) + 1;
    const price = (150 + Math.random() * 500).toFixed(2);
    await db.run(
      `INSERT INTO quotations (user_id, service_id, quantity, options, notes, estimated_price, status, created_at)
       VALUES (?, ?, ?, '{}', 'Please use company colours', ?, ?, datetime('now', '-' || ? || ' days'))`,
      [userId, serviceId, qty, price, i % 3 === 0 ? 'approved' : 'pending', i]
    );
  }
  console.log('Seeded 12 quotations');

  // ---- Orders + Items + Payments (12 orders) ----
  const statuses = ['pending', 'confirmed', 'in_production', 'ready', 'completed', 'shipped'];
  for (let i = 1; i <= 12; i++) {
    const userId = (i % 11) + 2;
    const status = statuses[i % statuses.length];
    const total = (200 + Math.random() * 2000).toFixed(2);

    const orderRes = await db.run(
      `INSERT INTO orders (user_id, status, total_amount, notes, created_at)
       VALUES (?, ?, ?, 'Rush order if possible', datetime('now', '-' || ? || ' days'))`,
      [userId, status, total, i * 2]
    );
    const orderId = orderRes.lastID;

    // 1-3 items per order
    const numItems = (i % 3) + 1;
    for (let j = 0; j < numItems; j++) {
      const serviceId = ((i + j) % 12) + 1;
      const qty = Math.floor(Math.random() * 20) + 1;
      const unit = 50 + Math.random() * 300;
      await db.run(
        `INSERT INTO order_items (order_id, service_id, quantity, options, unit_price, line_total)
         VALUES (?, ?, ?, '{"finish":"matte"}', ?, ?)`,
        [orderId, serviceId, qty, unit.toFixed(2), (unit * qty).toFixed(2)]
      );
    }

    // Payment for most orders
    if (status !== 'pending') {
      await db.run(
        `INSERT INTO payments (order_id, amount, method, status, transaction_id, paid_at)
         VALUES (?, ?, ?, 'completed', ?, datetime('now', '-' || ? || ' days'))`,
        [orderId, total, i % 2 === 0 ? 'card' : 'eft', `TXN-PH-${1000 + i}`, i * 2]
      );
    }
  }
  console.log('Seeded 12 orders with items and payments');

  // ---- Files (12) ----
  for (let i = 1; i <= 12; i++) {
    await db.run(
      `INSERT INTO files (order_id, user_id, original_name, stored_name, mime_type, size_bytes, uploaded_at)
       VALUES (?, ?, ?, ?, 'application/pdf', ?, datetime('now', '-' || ? || ' days'))`,
      [i, (i % 11) + 2, `design-file-${i}.pdf`, `stored-${i}.pdf`, 150000 + i * 10000, i]
    );
  }
  console.log('Seeded 12 files');

  console.log('\n✅ Database seeded successfully!');
  console.log('Admin login: admin@printhub.co.za / Admin@2026');
  console.log('Customer login: thabo.molefe@email.com / Password123!');
}

seed().catch(err => {
  console.error(err);
  process.exit(1);
});
