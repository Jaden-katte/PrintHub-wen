/**
 * PrintHub Online Printing Management System - REST API
 * XISD6329 WIL Task 2
 * Team: Boineelo Mkansie, Nkateko Baloyi, Khaogelo Matlala, Danny Riba, Kgotso Molefe, Ntlakuso Banyini
 */

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'printhub-secret-key-change-in-production-2026';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const unique = `${Date.now()}-${uuidv4()}${path.extname(file.originalname)}`;
    cb(null, unique);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
  fileFilter: (req, file, cb) => {
    const allowed = /pdf|doc|docx|jpg|jpeg|png|gif|ai|psd|eps|svg|zip/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype) || file.mimetype.includes('image') || file.mimetype.includes('pdf') || file.mimetype.includes('zip');
    if (ext || mime) return cb(null, true);
    cb(new Error('Invalid file type. Allowed: PDF, DOC, images, design files, ZIP'));
  }
});

// Auth middleware
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Access token required' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(403).json({ error: 'Invalid or expired token' });
    req.user = user;
    next();
  });
}

function requireAdmin(req, res, next) {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }
  next();
}

// ==================== AUTH ROUTES ====================

// Register
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password, phone } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const existing = await db.get('SELECT id FROM users WHERE email = ?', [email.toLowerCase()]);
    if (existing) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const passwordHash = await bcrypt.hash(password, 12);
    const result = await db.run(
      `INSERT INTO users (name, email, password_hash, phone, role, created_at) 
       VALUES (?, ?, ?, ?, 'customer', datetime('now'))`,
      [name, email.toLowerCase(), passwordHash, phone || null]
    );

    const token = jwt.sign(
      { id: result.lastID, email: email.toLowerCase(), role: 'customer', name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      message: 'Registration successful',
      token,
      user: { id: result.lastID, name, email: email.toLowerCase(), role: 'customer', phone }
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const user = await db.get('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, name: user.name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Google SSO / External SSO simulation (accepts Google ID token style payload for demo)
// In production use proper Google Auth Library verification
app.post('/api/auth/sso', async (req, res) => {
  try {
    const { email, name, provider = 'google', providerId } = req.body;
    if (!email || !name) {
      return res.status(400).json({ error: 'Email and name required for SSO' });
    }

    let user = await db.get('SELECT * FROM users WHERE email = ?', [email.toLowerCase()]);
    if (!user) {
      // Create user without password for SSO
      const result = await db.run(
        `INSERT INTO users (name, email, password_hash, role, sso_provider, sso_id, created_at) 
         VALUES (?, ?, '', 'customer', ?, ?, datetime('now'))`,
        [name, email.toLowerCase(), provider, providerId || null]
      );
      user = await db.get('SELECT * FROM users WHERE id = ?', [result.lastID]);
    }

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, name: user.name },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      message: 'SSO login successful',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone
      }
    });
  } catch (err) {
    console.error('SSO error:', err);
    res.status(500).json({ error: 'SSO authentication failed' });
  }
});

// Get current user profile
app.get('/api/auth/me', authenticateToken, async (req, res) => {
  try {
    const user = await db.get(
      'SELECT id, name, email, phone, role, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// Update profile / settings
app.put('/api/auth/settings', authenticateToken, async (req, res) => {
  try {
    const { name, phone, currentPassword, newPassword } = req.body;
    const user = await db.get('SELECT * FROM users WHERE id = ?', [req.user.id]);
    if (!user) return res.status(404).json({ error: 'User not found' });

    if (newPassword) {
      if (!currentPassword) {
        return res.status(400).json({ error: 'Current password required to set new password' });
      }
      const valid = await bcrypt.compare(currentPassword, user.password_hash);
      if (!valid && user.password_hash) {
        return res.status(401).json({ error: 'Current password is incorrect' });
      }
      const hash = await bcrypt.hash(newPassword, 12);
      await db.run('UPDATE users SET password_hash = ?, name = COALESCE(?, name), phone = COALESCE(?, phone) WHERE id = ?',
        [hash, name || null, phone || null, req.user.id]);
    } else {
      await db.run('UPDATE users SET name = COALESCE(?, name), phone = COALESCE(?, phone) WHERE id = ?',
        [name || null, phone || null, req.user.id]);
    }

    const updated = await db.get(
      'SELECT id, name, email, phone, role FROM users WHERE id = ?',
      [req.user.id]
    );
    res.json({ message: 'Settings updated', user: updated });
  } catch (err) {
    console.error('Settings error:', err);
    res.status(500).json({ error: 'Failed to update settings' });
  }
});

// ==================== SERVICES ====================

app.get('/api/services', async (req, res) => {
  try {
    const { category } = req.query;
    let services;
    if (category) {
      services = await db.all('SELECT * FROM services WHERE category = ? AND active = 1 ORDER BY name', [category]);
    } else {
      services = await db.all('SELECT * FROM services WHERE active = 1 ORDER BY category, name');
    }
    res.json(services);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch services' });
  }
});

app.get('/api/services/:id', async (req, res) => {
  try {
    const service = await db.get('SELECT * FROM services WHERE id = ?', [req.params.id]);
    if (!service) return res.status(404).json({ error: 'Service not found' });
    res.json(service);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch service' });
  }
});

// Admin: create/update services
app.post('/api/services', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { name, description, category, base_price, unit } = req.body;
    const result = await db.run(
      `INSERT INTO services (name, description, category, base_price, unit, active, created_at)
       VALUES (?, ?, ?, ?, ?, 1, datetime('now'))`,
      [name, description, category, base_price, unit || 'item']
    );
    const service = await db.get('SELECT * FROM services WHERE id = ?', [result.lastID]);
    res.status(201).json(service);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create service' });
  }
});

// ==================== QUOTATIONS ====================

app.post('/api/quotations', authenticateToken, async (req, res) => {
  try {
    const { service_id, quantity, options, notes } = req.body;
    const service = await db.get('SELECT * FROM services WHERE id = ?', [service_id]);
    if (!service) return res.status(404).json({ error: 'Service not found' });

    const estimated = (service.base_price * (quantity || 1)).toFixed(2);
    const result = await db.run(
      `INSERT INTO quotations (user_id, service_id, quantity, options, notes, estimated_price, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 'pending', datetime('now'))`,
      [req.user.id, service_id, quantity || 1, JSON.stringify(options || {}), notes || null, estimated]
    );
    const quote = await db.get('SELECT * FROM quotations WHERE id = ?', [result.lastID]);
    res.status(201).json(quote);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create quotation' });
  }
});

app.get('/api/quotations', authenticateToken, async (req, res) => {
  try {
    let quotes;
    if (req.user.role === 'admin') {
      quotes = await db.all(`
        SELECT q.*, u.name as user_name, s.name as service_name 
        FROM quotations q 
        JOIN users u ON q.user_id = u.id 
        JOIN services s ON q.service_id = s.id 
        ORDER BY q.created_at DESC`);
    } else {
      quotes = await db.all(`
        SELECT q.*, s.name as service_name 
        FROM quotations q 
        JOIN services s ON q.service_id = s.id 
        WHERE q.user_id = ? 
        ORDER BY q.created_at DESC`, [req.user.id]);
    }
    res.json(quotes);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch quotations' });
  }
});

// ==================== ORDERS ====================

app.post('/api/orders', authenticateToken, async (req, res) => {
  try {
    const { items, notes } = req.body; // items: [{service_id, quantity, options}]
    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'At least one order item required' });
    }

    let total = 0;
    const orderItems = [];
    for (const item of items) {
      const service = await db.get('SELECT * FROM services WHERE id = ?', [item.service_id]);
      if (!service) return res.status(404).json({ error: `Service ${item.service_id} not found` });
      const price = service.base_price * (item.quantity || 1);
      total += price;
      orderItems.push({ ...item, unit_price: service.base_price, line_total: price, service_name: service.name });
    }

    const orderResult = await db.run(
      `INSERT INTO orders (user_id, status, total_amount, notes, created_at)
       VALUES (?, 'pending', ?, ?, datetime('now'))`,
      [req.user.id, total.toFixed(2), notes || null]
    );
    const orderId = orderResult.lastID;

    for (const item of orderItems) {
      await db.run(
        `INSERT INTO order_items (order_id, service_id, quantity, options, unit_price, line_total)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [orderId, item.service_id, item.quantity || 1, JSON.stringify(item.options || {}), item.unit_price, item.line_total]
      );
    }

    const order = await db.get('SELECT * FROM orders WHERE id = ?', [orderId]);
    const dbItems = await db.all('SELECT * FROM order_items WHERE order_id = ?', [orderId]);
    res.status(201).json({ ...order, items: dbItems });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create order' });
  }
});

app.get('/api/orders', authenticateToken, async (req, res) => {
  try {
    let orders;
    if (req.user.role === 'admin') {
      orders = await db.all(`
        SELECT o.*, u.name as customer_name, u.email as customer_email
        FROM orders o JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC`);
    } else {
      orders = await db.all(
        'SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC',
        [req.user.id]
      );
    }
    res.json(orders);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

app.get('/api/orders/:id', authenticateToken, async (req, res) => {
  try {
    const order = await db.get('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (req.user.role !== 'admin' && order.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
    const items = await db.all(`
      SELECT oi.*, s.name as service_name 
      FROM order_items oi JOIN services s ON oi.service_id = s.id 
      WHERE oi.order_id = ?`, [order.id]);
    const files = await db.all('SELECT * FROM files WHERE order_id = ?', [order.id]);
    const payment = await db.get('SELECT * FROM payments WHERE order_id = ?', [order.id]);
    res.json({ ...order, items, files, payment });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch order' });
  }
});

// Admin update order status
app.patch('/api/orders/:id/status', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    const valid = ['pending', 'confirmed', 'in_production', 'ready', 'shipped', 'completed', 'cancelled'];
    if (!valid.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    await db.run('UPDATE orders SET status = ?, updated_at = datetime("now") WHERE id = ?', [status, req.params.id]);
    const order = await db.get('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: 'Failed to update status' });
  }
});

// ==================== FILE UPLOAD ====================

app.post('/api/orders/:id/files', authenticateToken, upload.single('file'), async (req, res) => {
  try {
    const order = await db.get('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (req.user.role !== 'admin' && order.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
    if (!req.file) return res.status(400).json({ error: 'No file uploaded' });

    const result = await db.run(
      `INSERT INTO files (order_id, user_id, original_name, stored_name, mime_type, size_bytes, uploaded_at)
       VALUES (?, ?, ?, ?, ?, ?, datetime('now'))`,
      [order.id, req.user.id, req.file.originalname, req.file.filename, req.file.mimetype, req.file.size]
    );
    const file = await db.get('SELECT * FROM files WHERE id = ?', [result.lastID]);
    res.status(201).json(file);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'File upload failed' });
  }
});

// ==================== PAYMENTS ====================

app.post('/api/orders/:id/payments', authenticateToken, async (req, res) => {
  try {
    const order = await db.get('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (order.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied' });
    }

    const { method = 'card', amount } = req.body;
    const payAmount = amount || order.total_amount;

    // Simulate payment processing
    const transactionId = `TXN-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;

    const result = await db.run(
      `INSERT INTO payments (order_id, amount, method, status, transaction_id, paid_at)
       VALUES (?, ?, ?, 'completed', ?, datetime('now'))`,
      [order.id, payAmount, method, transactionId]
    );

    await db.run('UPDATE orders SET status = "confirmed", updated_at = datetime("now") WHERE id = ?', [order.id]);

    const payment = await db.get('SELECT * FROM payments WHERE id = ?', [result.lastID]);
    res.status(201).json(payment);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Payment failed' });
  }
});

// ==================== ADMIN DASHBOARD STATS ====================

app.get('/api/admin/stats', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const users = await db.get('SELECT COUNT(*) as count FROM users WHERE role = "customer"');
    const orders = await db.get('SELECT COUNT(*) as count FROM orders');
    const pending = await db.get('SELECT COUNT(*) as count FROM orders WHERE status = "pending"');
    const revenue = await db.get('SELECT COALESCE(SUM(amount), 0) as total FROM payments WHERE status = "completed"');
    res.json({
      customers: users.count,
      totalOrders: orders.count,
      pendingOrders: pending.count,
      totalRevenue: revenue.total
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'PrintHub API', version: '1.0.0' });
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  if (err instanceof multer.MulterError) {
    return res.status(400).json({ error: err.message });
  }
  res.status(500).json({ error: err.message || 'Internal server error' });
});

// Start
db.init().then(() => {
  app.listen(PORT, () => {
    console.log(`PrintHub API running on http://localhost:${PORT}`);
    console.log(`Health: http://localhost:${PORT}/api/health`);
  });
}).catch(err => {
  console.error('Failed to initialise database:', err);
  process.exit(1);
});
