// PrintHub API configuration
// Change this to your deployed API URL when hosting
const API_BASE = localStorage.getItem('printhub_api') || 'http://localhost:3000/api';

const PrintHub = {
  apiBase: API_BASE,

  async request(endpoint, options = {}) {
    const token = localStorage.getItem('printhub_token');
    const headers = {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    };
    if (token) headers['Authorization'] = `Bearer ${token}`;

    const res = await fetch(`${this.apiBase}${endpoint}`, {
      ...options,
      headers
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      const err = new Error(data.error || `Request failed (${res.status})`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data;
  },

  getToken() { return localStorage.getItem('printhub_token'); },
  getUser() {
    try { return JSON.parse(localStorage.getItem('printhub_user') || 'null'); }
    catch { return null; }
  },
  setSession(token, user) {
    localStorage.setItem('printhub_token', token);
    localStorage.setItem('printhub_user', JSON.stringify(user));
  },
  clearSession() {
    localStorage.removeItem('printhub_token');
    localStorage.removeItem('printhub_user');
  },
  isLoggedIn() { return !!this.getToken(); },
  isAdmin() {
    const u = this.getUser();
    return u && u.role === 'admin';
  }
};
