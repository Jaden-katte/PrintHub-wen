// Shared auth UI helpers
document.addEventListener('DOMContentLoaded', () => {
  updateAuthUI();

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      PrintHub.clearSession();
      window.location.href = '/index.html';
    });
  }

  const menuToggle = document.getElementById('menuToggle');
  const nav = document.getElementById('nav');
  if (menuToggle && nav) {
    menuToggle.addEventListener('click', () => nav.classList.toggle('open'));
  }
});

function updateAuthUI() {
  const loggedIn = PrintHub.isLoggedIn();
  const admin = PrintHub.isAdmin();

  document.querySelectorAll('.auth-only').forEach(el => {
    el.style.display = loggedIn ? '' : 'none';
  });
  document.querySelectorAll('.guest-only').forEach(el => {
    el.style.display = loggedIn ? 'none' : '';
  });
  document.querySelectorAll('.admin-only').forEach(el => {
    el.style.display = admin ? '' : 'none';
  });
}

function requireAuth(redirect = 'login.html') {
  if (!PrintHub.isLoggedIn()) {
    window.location.href = redirect;
    return false;
  }
  return true;
}

function requireAdmin() {
  if (!PrintHub.isAdmin()) {
    window.location.href = '../index.html';
    return false;
  }
  return true;
}

function showAlert(containerId, message, type = 'error') {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
}

function clearAlert(containerId) {
  const el = document.getElementById(containerId);
  if (el) el.innerHTML = '';
}
