// Home page enhancements (optional)
console.log('PrintHub website loaded. API:', PrintHub.apiBase);
